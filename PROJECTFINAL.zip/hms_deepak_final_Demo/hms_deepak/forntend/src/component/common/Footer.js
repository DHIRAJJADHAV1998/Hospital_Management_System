import React from 'react'

export default function Footer(){
  return (
  
    <div><p>Copyright@CDAC-2022</p></div>
     )
}
