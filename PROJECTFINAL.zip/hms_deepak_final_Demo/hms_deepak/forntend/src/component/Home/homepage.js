import React from 'react';
// import { useNavigate } from 'react-router-dom';
import "./home.css";



const Home = ()=>{

    // const navigate = useNavigate();
    
    return (
    <div className ="home">
     {/* <div className = "card">
     <h1>Welcome</h1>
     <h1>Hospital Management System</h1>
     <button onClick={()=>{navigate("/login")}} type="submit">Login</button>
     <div id="or">or</div>
     <button onClick={()=>{navigate("/register")}} type="submit">Register</button>
     </div> */}

 </div>
 )
}

export default Home;
