import React from 'react'

export default function updateDoc() {
  return (
    <div>updateDoc</div>
  )
}
