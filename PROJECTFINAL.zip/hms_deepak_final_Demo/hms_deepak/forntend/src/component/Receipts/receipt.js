
import React, { useEffect, useState } from "react";
import Table from "./Table";

let Receipt = () => {
 
  return <div className="bill">
   
    
    {<Table/>}
    
    
    </div>;

};
export default Receipt;
