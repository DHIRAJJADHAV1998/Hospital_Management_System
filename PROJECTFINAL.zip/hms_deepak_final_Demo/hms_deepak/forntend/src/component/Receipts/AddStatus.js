import React from "react";
import Status from "./Status";

let AddStatus = () => {
  return <div>{<Status />}</div>;
};
export default AddStatus;
